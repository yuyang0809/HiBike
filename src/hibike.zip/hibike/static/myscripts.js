function sub(n){
  var content=$("#stationId").val();
  var method=$("option[name=searchOption]:checked").val();
  var stationList=[];
  document.getElementById("match").innerHTML='';
  if(n==1 && method=="Your address"){
    data_to_backend = {'Id':'searchForm','address':content};
    alert($SCRIPT_ROOT);
    alert("／communicate")
    $.getJSON($SCRIPT_ROOT + "/communicate'", data_to_backend, function(data){
      data=JSON.parse(data);
      window.location.href="/station/"+data['station'];
    });
  }else if(content != '')
  {
    for(var i=0; i<stationData.length; i++){
      switch (method) {
        case "Station Name":
          if(stationData[i][1].replace(/[ ]/g,"").toLowerCase().indexOf(content.replace(/[ ]/g,"").toLowerCase())>=0){
            if(n==0){
              document.getElementById("match").innerHTML += "<a href='/station/"+stationData[i][0]+"'>"+stationData[i][1]+'</a><br>';
            }else{
              stationList.push(stationData[i][0]);
              }
            }
          break;
        case "Station Number":
          if(n==0){
            if(stationData[i][0].toString().replace(/[ ]/g,"").indexOf(content.toString().replace(/[ ]/g,""))>=0){
              document.getElementById("match").innerHTML += "<a href='/station/"+stationData[i][0]+"'>"+stationData[i][0]+'</a><br>';
            }
          } else{
            var testlist = [parseInt(stationData[i][0]),]
            if(testlist.includes(parseInt(content))){
              stationList.push(stationData[i][0]);
            }
          };
          break;
        case "Station Address":
          if(stationData[i][2].toLowerCase().replace(/[ ]/g,"").indexOf(content.replace(/[ ]/g,"").toLowerCase())>=0){
            if(n==0){
              document.getElementById("match").innerHTML += "<a href='/station/"+stationData[i][0]+"'>"+stationData[i][2]+'</a><br>';
            }
            else{
              stationList.push(stationData[i][0]);
            }
          };
          break;
      }
    }
    if (n==1){
      if(stationList.length==1){
        window.location.href="/station/"+stationList[0];
      }else{
        alert("Your station is not correct.")
      }
    }
  }
}

  
function fillInAddress() {
  $("#searchForm").bind("input propertychange",function(){
  if( method=="Your address"){ 
      // Get the place details from the autocomplete object.
      var place = autocomplete.getPlace();

      for (var component in componentForm) {
        document.getElementById(component).value = '';
        document.getElementById(component).disabled = false;
      }

      // Get each component of the address from the place details
      // and fill the corresponding field on the form.
      for (var i = 0; i < place.address_components.length; i++) {
        var addressType = place.address_components[i].types[0];
        if (componentForm[addressType]) {
          var val = place.address_components[i][componentForm[addressType]];
          document.getElementById(addressType).value = val;
        }
      }
    }
  });
}
