from test_pandas import train
import pandas as pd
import requests
from datetime import datetime
import mysql.connector

conn = mysql.connector.connect(user='root', password='2978291', database='HiBike')
cur = conn.cursor()
cur.execute("select * from Bike_Stations")
stationData = cur.fetchall()
stationData[0][0]


def getformlation():
	dict = {}
	for i in stationData:
		i[0]
		dict[i[0]] = train(i[0])
	return(dict)
predict = (getformlation())

form = predict[1]
X = pd.DataFrame({'humidity': [93.00], 'temp': [280.15], 'visibility': [6000.00], 'wind': [4.00], 'month': [4.00], 'day': [13.00], 
		'hour': [1.00], 'minute': [0.00], 'pre_available_bikes': [1.00], 'weather_main_Clear': [0.00], 'weather_main_Clouds': [0.00],
		'weather_main_Drizzle': [1.00], 'weather_main_Fog': [0.00], 'weather_main_Mist': [0.00], 'weather_main_Rain': [0.00], 
		'weekday_Friday': [1.00], 'weekday_Monday': [0.00], 'weekday_Saturday': [0.00], 'weekday_Sunday': [0.00] })
print(form.predict(X))