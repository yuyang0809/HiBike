import threading as thd
import time
from sklearn.ensemble import RandomForestClassifier
from test_pandas import train
import mysql.connector
import json
import requests
from datetime import datetime
import pandas as pd

rds_host='mybike.c0jxuz6r8olg.us-west-2.rds.amazonaws.com'
name='hibike'
pwd='zx123456'
db_name='bike'
port=3306

conn = mysql.connector.connect(host=rds_host,user=name, password=pwd, database=db_name)
cur = conn.cursor()

di={}
diCol = {}
def renewdict():
    global di
    global diCol
    print('work')
    di, diCol = getformlation()
    print('done')
    thd.Timer(86400,renewdict).start()

def getformlation():
    di = {}
    diCol = {}
    #for i in stationData:
        #di[i[0]], diCol[i[0]] = train(i[0])
    di[1], diCol[1] = train(1)

    return(di, diCol)

t = thd.Thread(target=renewdict, name='renewThread')
t.start()

def ha():
    cur.execute('select * from station_1 ORDER BY last_update DESC limit 0, 1')
    detailData = cur.fetchone()
    diCol_pr = {}
    global diCol
    global di
    try:
        for i in diCol[1]:
            diCol_pr[i] = 0

        r_w = requests.get('http://api.openweathermap.org/data/2.5/forecast?q=Dublin,IE&APPID=7b3e054e55cf81602b4298ca04a0fa18')

        diCol_pr['pre_available_bikes'] = detailData[-1]
        di['pre_minute'] = detailData[0].hour * 60 + detailData[0].minute

        diCol_pr['day'] = datetime.utcfromtimestamp(r_w.json()['list'][0]['dt']).day
        diCol_pr['hour'] = datetime.utcfromtimestamp(r_w.json()['list'][0]['dt']).hour
        diCol_pr['humidity'] = r_w.json()['list'][0]['main']['humidity']
        diCol_pr['minute'] = datetime.utcfromtimestamp(r_w.json()['list'][0]['dt']).minute + datetime.utcfromtimestamp(r_w.json()['list'][0]['dt']).hour * 60
        diCol_pr['temp'] = r_w.json()['list'][0]['main']['temp']
        diCol_pr['wind'] = r_w.json()['list'][0]['wind']['speed']

        weather = r_w.json()['list'][0]['weather'][0]['main']
        weekdays = ['Monday', 'Tuesday', 'Wednesday', 'Thursday',
                    'Friday', 'Saturday', 'Sunday']
        weekday = weekdays[datetime.utcfromtimestamp(r_w.json()['list'][0]['dt']).weekday()]
        if 'weather_main_{}'.format(weather) in diCol_pr.keys():
            diCol_pr['weather_main_{}'.format(weather)] = 1
            if 'weekday_{}'.format(weekday) in diCol_pr.keys():
                diCol_pr['weekday_{}'.format(weekday)] = 1

                predi = pd.DataFrame([diCol_pr])
                rfc_predictions = "available_bikes : {}".format(int(di[1].predict(predi)))
            else:
                rfc_predictions = "Something wrong, day information get error."
        else:
            rfc_predictions = "A new weather may appear, not enough data to make a prediction."
    except Exception as e:
        rfc_predictions = "We rebuild the prediction module, please try 10 minutes late."

time.sleep(5)
ha()
